<!DOCTYPE html>
<html lang="en">
<head>
    <title>basicApp</title>
    <script type="text/javascript"  src="https://code.jquery.com/jquery-3.7.0.min.js" integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script type="text/javascript"  src="https://cdn.shopify.com/shopifycloud/app-bridge.js?apiKey={{ env.SHOPIFY_API_KEY }}"></script>
    <script type="text/javascript"  src="https://unpkg.com/@shopify/app-bridge@3.7.10/umd/index.js"></script>
    <script type="text/javascript" src="https://unpkg.com/@shopify/app-bridge-utils@3.5.1/umd/index.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.1/spectrum.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.1/spectrum.min.css" />

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="shopify-api-key" content="{{ env.SHOPIFY_API_KEY}}" />
    <!-- <meta http-equiv="Content-Security-Policy" content="frame-ancestors 'https://admin.shopify.com' '<?php echo $_GET['shop']; ?>'"> -->

 
    <script src="{{ env.BASE_URL }}/custom.js?timestamp={{ 'now'|date('U') }}" type="text/javascript"></script>
    <link rel="stylesheet" href="{{ env.BASE_URL }}/custom.css?timestamp={{ 'now'|date('U') }}" >
    <link rel="stylesheet" href="https://unpkg.com/@shopify/polaris@13.9.3/build/esm/styles.css" />
    <link rel="preconnect" href="https://cdn.shopify.com/" />
    <link rel="stylesheet" href="https://cdn.shopify.com/static/fonts/inter/v4/styles.css" />
</head>
<body>

    

    <input type="hidden" name="appUrl" id="appUrl" value="{{ env.NGROK_URL }}">
    <input type="hidden" name="shopUrl" id="shopUrl" value="{{ shopUrl }}">
  
    {% set shopURL =  shopUrl  %}
    {% set shopifyApiKey = env.SHOPIFY_API_KEY %}
    {% set app_url = "https://" ~ shopURL ~ "/admin/apps/" ~ env.APP_URL_ID %}

    <script>
        var SHOPIFY_API_KEY = "{{ shopifyApiKey|e('js') }}";
    </script>


    <div class="Polaris-Frame" data-polaris-layer="true">
        <div class="Polaris-Frame__ContextualSaveBar Polaris-Frame-CSSAnimation--startFade">
        </div>
        <main class="Polaris-Frame__Main" id="AppFrameMain" data-has-global-ribbon="false">
            <div class="Polaris-Frame__Content" style="display:flex">
                <div class="mainContent">
                    <div class="Polaris-Page">
                        <div class="nav">
					        <a class="Polaris-Button Polaris-Button--pressable Polaris-Button--variantPrimary Polaris-Button--sizeMedium Polaris-Button--textAlignCenter" data-page="dashboard">Dashboard</a>
					        <a class="Polaris-Button Polaris-Button--pressable Polaris-Button--variantPrimary Polaris-Button--sizeMedium Polaris-Button--textAlignCenter" data-page="getdata">Get Data</a>
					         <a class="Polaris-Button Polaris-Button--pressable Polaris-Button--variantPrimary Polaris-Button--sizeMedium Polaris-Button--textAlignCenter" data-page="loadnewpage">load new Page</a>
					        
					    </div>

                         <div id="shopify_app"></div>
                        
 
<script>
    function getUrlParameter(name) {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    function loadPage(page) {
        var shopUrl = getUrlParameter('shop');
        var hmac = getUrlParameter('hmac');
        var timestamp = getUrlParameter('timestamp');

        var url = `/basicApp/${page}?shop=${encodeURIComponent(shopUrl)}&hmac=${encodeURIComponent(hmac)}&timestamp=${encodeURIComponent(timestamp)}`;

        $('#shopify_app').html('<p>Loading...</p>');

        $.ajax({
            url: url,  
            type: 'GET',
            success: function(response) {
                $('#shopify_app').html(response);
            },
            error: function() {
                $('#shopify_app').html('<p>Error loading content.</p>');
            }
        });
    }

    $(document).on('click', '.nav a', function(e) {
        e.preventDefault();
        var page = $(this).data('page');
        $('.nav a').removeClass('active');
        $(this).addClass('active');
        loadPage(page);
    });

    $(document).ready(function() {
        loadPage('dashboard');
    });
</script>


                  </div>
                </div>  
            </div>
        </main>
    </div>
    <footer>
        <div class="Polaris-FooterHelp">
            <center><p>Footer</p></center>
        </div>
    </footer>
    
</body>

</html>